package servlet;

public interface Componente {
    public String mostrarInformacion();
}
