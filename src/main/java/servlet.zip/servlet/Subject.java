package servlet;

public interface Subject {
    public float acceso(String correo, String password);
    public String ejecutarOperaciones(String operacion);
}
