package servlet;

public interface ComponenteAlarma {
    public String mostrarInformacion();
}
